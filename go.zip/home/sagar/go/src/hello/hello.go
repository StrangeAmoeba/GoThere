package main

import (
		"fmt"
)

func main() {
	var a [5][5]int = [5][5]int{{5,6,7,8,9},{5,6,7,8,9},{5,6,7,8,9},{5,6,7,8,9},{5,6,7,8,9}}
	
	fmt.Println(a)

}